package com.at.facebooktypeimagegrid.Assymetric;

public interface PoolObjectFactory<T> {
  T createObject();
}
